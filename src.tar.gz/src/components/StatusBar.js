import React from "react";
import { StatusBar } from "react-native";

const statusBar = () => {
  return <StatusBar style="none" />;
};

export default statusBar;
