const images = {
  Service: require("../assets/images/Service.png"),
  Statment: require("../assets/images/Statment.png"),
  Payment: require("../assets/images/payment.png"),
  Money: require("../assets/images/money.png"),
  Avail: require("../assets/images/avail.png"),
};
export default images;
