const Colors = {
  background: "#646464",
  background_secondary: "#F6F6F6",
  button_background: "#595959",
  button_name: "#FFFFFF",
  header_title: "#FFFFFF",
  border_Color: "#BABABA",
  card_title: "#B5B5B5",
  amount_title: "#E1E1E1",
  amount_text: "#FFFFFF",
  footer_title: "#B5B5B5",
  progree_background: "#FFFFFF",
  progress_title: "#E1E1E1",
  progress_text: "#FFFFFF",
  text: "#818181",
};

export default Colors;
