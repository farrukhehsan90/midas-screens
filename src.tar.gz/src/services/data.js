export const data = [
  {
    id: "1",
    image: require("../assets/images/money.png"),
    Title: "Personal Loan",
    numberOfLoans: "2",
    loan: "Loans",
    price: "₹ 2,00,000",
  },
  {
    id: "2",
    image: require("../assets/images/money.png"),
    Title: "Car Loan",
    numberOfLoans: "1",
    loan: "Loans",
    price: "₹ 1,50,000",
  },
];
